var cocher = document.getElementsByClassName("cocher"); // récupère les cases à cocher (un array)

for (y in cocher){ // Ajoute un Event Listener à chaque boite à cocher
	cocher[y].addEventListener("change", checkP);
}

function checkP(){ //création d'une fonction
	var initial = 400; // variable qui détient la valeur par défaut
	var plus = 0;// variable plus qui contiendra la valeur à ajouter

	for (i in cocher){ // pour chaque case à cocher de la page
		if(cocher[i].checked){ //si la case actuelle est coché
		plus += parseInt(cocher[i].value); //ajoute la valeur (en integer) de la case a la variable "plus"
		}
	}
	var plus = plus / 2;
	var p = initial + plus; // crée une variable qui contient la valeur de initial + plus
	var prix = p + "$"; // Ajoute le signe de dollars
	document.getElementById("total").innerHTML = prix; // écris le prix dans le span "total"
}
