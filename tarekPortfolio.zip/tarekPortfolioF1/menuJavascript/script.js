var posiDate = document.getElementById("date");
var posiMois = document.getElementById("mois");
var posiHeure = document.getElementById("heure");
var date = new Date();
var jour = date.getDay();
var mois = date.getMonth();
var annee = date.getFullYear();
var jourMois = date.getDate();
var h = date.getHours();
var min = date.getMinutes();

if(h < 10){h = "0" + h};
if(min < 10){min = "0" + min};

switch (jour){
	case 0 : posiDate.innerHTML = "Dimanche "+ jourMois; break;
	case 1 : posiDate.innerHTML = "Lundi "+ jourMois; break;
	case 2 : posiDate.innerHTML = "Mardi "+ jourMois; break;
	case 3 : posiDate.innerHTML = "Mercredi "+ jourMois; break;
	case 4 : posiDate.innerHTML = "Jeudi "+ jourMois; break;
	case 5 : posiDate.innerHTML = "Vendredi "+ jourMois; break;
	case 6 : posiDate.innerHTML = "Samedi "+ jourMois; break;
	default : posiDate.innerHTML = "Désolé, cette journée n'existe pas."; break;
}

switch(mois){
		case 0 : posiMois.innerHTML = "janvier "+ annee; break;
		case 1 : posiMois.innerHTML = "février "+annee; break;
		case 2 : posiMois.innerHTML = "mars " +annee; break;
		case 3 : posiMois.innerHTML = "avril " +annee; break;
		case 4 : posiMois.innerHTML = "mai " +annee; break;
		case 5 : posiMois.innerHTML = "juin " +annee; break;
		case 6 : posiMois.innerHTML = "juillet " +annee; break;
		case 7 : posiMois.innerHTML = "août " +annee; break;
		case 8 : posiMois.innerHTML = "septembre " +annee; break;
		case 9 : posiMois.innerHTML = "octobre " +annee; break;
		case 10 : posiMois.innerHTML = "novembre " +annee; break;
		case 11 : posiMois.innerHTML = "décembre " +annee; break;
		default : posiMois.innerHTML = "Désolé, ce mois n'existe pas."; break;
}
posiHeure.innerHTML = h + "h" + min; 
