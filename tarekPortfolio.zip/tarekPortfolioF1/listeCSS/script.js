var lieux = document.getElementsByTagName("li");

for(i=0; i < lieux.length; i++){
	if(i % 2 == 0){
		lieux[i].style.backgroundColor = "pink";
	}
}
