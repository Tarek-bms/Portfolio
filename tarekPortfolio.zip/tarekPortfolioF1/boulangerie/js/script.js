var imageActuelle = 1; 
affichageImage(imageActuelle);

function btnChangementImage(bla) {
  affichageImage(imageActuelle += bla); 
}

function affichageImage(slide) {
  // Récupère les images du slider
	var images = document.querySelectorAll(".slide");
	
	// 2 conditions qui affiche l'image 1 après la dernière image et la dernière image avant la première.
	if (slide > images.length) {imageActuelle = 1} // dernière image à la première image.  
  if (slide < 1) {imageActuelle = images.length} // première image à la dernière image.
  
	// boucle qui chache toutes les images.
	for (var i = 0; i < images.length; i++) {
		images[i].style.display = "none";
  }
	
	// affiche l'image sélectionné.
	images[imageActuelle-1].style.display = "block";
}