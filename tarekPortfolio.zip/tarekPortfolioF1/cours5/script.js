
$(document).ready(function(){
    $("button").click(function(){
        $("p").css("background-color", "red");
    });
});