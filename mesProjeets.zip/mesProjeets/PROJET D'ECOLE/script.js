function parallax() {
  var scrolled = $(window).scrollTop();
  var parallaxInstance = $('.parallax-container').toArray()

  for (i = 0; i < parallaxInstance.length; i++) {
    var parallaxTop = $(parallaxInstance[i]).offset().top;
    var parallaxBot = $(parallaxInstance[i]).offset().top + $(parallaxInstance[i]).outerHeight();
    var parallaxEffect = (scrolled / parallaxBot + .25) * 100;
    //$(parallaxInstance[i]).children(".parallax").css('margin-top', (parallaxEffect));//
    $(parallaxInstance[i]).children(".parallax").css('top', ((1257 + scrolled - parallaxBot) * 0.5) + 'px');
  }
}

$(window).scroll(function () {
    parallax();
});

$(window).ready(function () {
    parallax();
});
function rand(min, max) {
  return Math.floor(Math.random() * max) + min;
}

document.querySelectorAll('.post:not(.featured)').forEach((post) => {
  post.querySelector('.image').style.backgroundImage = `url("https://unsplash.it/300/300/?image=${rand(100, 1000)}")`;
});
  $(document).ready(function(){
            var submitIcon = $('.searchbox-icon');
            var inputBox = $('.searchbox-input');
            var searchBox = $('.searchbox');
            var isOpen = false;
            submitIcon.click(function(){
                if(isOpen == false){
                    searchBox.addClass('searchbox-open');
                    inputBox.focus();
                    isOpen = true;
                } else {
                    searchBox.removeClass('searchbox-open');
                    inputBox.focusout();
                    isOpen = false;
                }
            });  
             submitIcon.mouseup(function(){
                    return false;
                });
            searchBox.mouseup(function(){
                    return false;
                });
            $(document).mouseup(function(){
                    if(isOpen == true){
                        $('.searchbox-icon').css('display','block');
                        submitIcon.click();
                    }
                });
        });
            function buttonUp(){
                var inputVal = $('.searchbox-input').val();
                inputVal = $.trim(inputVal).length;
                if( inputVal !== 0){
                    $('.searchbox-icon').css('display','none');
                } else {
                    $('.searchbox-input').val('');
                    $('.searchbox-icon').css('display','block');
                }
            }