<?php  
$sql=mysqli_connect("localhost","root","root","francis_vacanciers");//connection et verifier la connection
if(!$sql){ }//etape de verification 
//fin de connexion /verification
$ID_Client=mysqli_real_escape_string($sql,$_REQUEST['ID_Client'] );
$Destination=mysqli_real_escape_string($sql,$_REQUEST['Destination'] );
$Depart=mysqli_real_escape_string($sql,$_REQUEST['Depart'] );
$Fin=mysqli_real_escape_string($sql,$_REQUEST['Fin'] );
$Activite=mysqli_real_escape_string($sql,$_REQUEST['Activite'] );

$requete="INSERT INTO voyage(ID, ID_Client, Destination, Depart, Fin,Activite ) VALUES ('NULL', '$ID_Client', '$Destination', '$Depart', '$Fin', '$Activite')";//création de la requette d'insert

if (mysqli_query($sql, $requete)) { 
        echo 'yes1';
      }
      else{
        echo 'non1';
      }
	mysqli_close($sql);
 ?>
