<?php  
$sql=mysqli_connect("localhost","root","root","francis_vacanciers");//connection et verifier la connection
if(!$sql){ }//etape de verification 
//fin de connexion /verification

//variabiser+nettoyer variables du formulaire
$ID_voyage=mysqli_real_escape_string($sql,$_REQUEST['ID_voyage'] );//traiter les variables+(nettoyer les info)
$Depense=mysqli_real_escape_string($sql,$_REQUEST['Depense'] );//traiter les variables+(nettoyer les info)

$requete2="INSERT INTO finance(ID, ID_voyage, Depense) VALUES ('NULL', '$ID_voyage', '$Depense')";//création de la requette d'insert
if (mysqli_query($sql, $requete2)) { 
        echo 'yes';
      }
      else{
        echo 'non';
      }

	mysqli_close($sql);
mysqli_query($sql, $requete);
?>                  