<html>
<head>
  <title>Ajouter des infos | Power Vacances Inc.</title>
  <link rel="stylesheet" href="style.css">
</head>
<div class="nav">
    <ul id="nav">
      <li id="email">
        <a href="ajouter.php">
          <img src="http://grantcr.com/files/iemail.png" AJOUTER/>
        </a>
      </li>
      <li id="photo">
        <a href="modifier.php">
          <img src="http://grantcr.com/files/iphoto.png"  MODIFIER/>
        </a>
      </li>
      <li id="cloud" class="active">
        <a href="supprimer.php">
          <img src="http://grantcr.com/files/icloud.png" / SUPPRIMER>
        </a>
      </li>
     
    </ul>
  </div>
<body>
  <h1>Bienvenue sur la page d'administration de </strong>Power Vacances Inc.</strong></h1>
  <h2>Veuillez remplir les champs appropriés pour supprimer des informations</h2>
  <h3>Supprimer un client</h3>
  <form action="supprimer.php" method="POST">
     <select name="ID_select" size="1" class="info">
      <!-- Affiche les information provenant de la bd, requete SQL pour aller chercher les information et les mettre dans option.-->
        <?php 
          //  connection
          $sql=mysqli_connect("localhost", "root", "root", "francis_vacanciers");
            if (!$sql) {
            }
          //fin de connection 

          //requete
          $requete= "SELECT * FROM client";  
          // fin de requete
          
          //effectuer la requete
          $requeteAffiche=mysqli_query($sql, $requete);

          //Boucle pour tout afficher dans les options du formulaire
          while ($resultat=mysqli_fetch_assoc($requeteAffiche)){
            echo "<option value=\"" . $resultat['ID'] . "\">";
            echo $resultat['NomClient'] . "-" . $resultat['Situation'] . "-" . $resultat['Telephone'] . "-" . $resultat['Adresse'] . "-" . $resultat['Ville'] . "-" . $resultat['Province'] . "-" . $resultat['Pays'] . "-" . $resultat['CodePostal'] . "-" . $resultat['Adhesion'];
            echo "</option>"; 
          }
          mysqli_close($sql);

        ?>        
        </select>
    <input type="submit" name="" value="Selectionner" class="envoyer">
     <?php if($_REQUEST['ID_select']) { /*On vérifi si une valeur à été selectionner*/?> 
    <!-- 2ème action du formulaire-->

      <form action="supprimer.php" method="POST"> <!-- Si on enlève action, la page va se rafraichir d'elle même naturellement-->
        <div> 

          <?php 
            //  connection
              $sql=mysqli_connect("localhost", "root", "root", "francis_vacanciers");
                if (!$sql) {
                }
            //fin de connection 

            //nettoyage de la variable
              $selection_ID_net= mysqli_real_escape_string($sql, $_REQUEST['ID_select']);

            //requete
              $requete= "SELECT * FROM client WHERE ID = $selection_ID_net"; 
            // fin de requete
            
            //effectuer la requete
              $requeteAffiche=mysqli_query($sql, $requete);

            //Boucle pour tout afficher des les options du formulaire
              while ($resultat=mysqli_fetch_assoc($requeteAffiche)){
                echo '<input type="text"  name="id_bloqu" value="' . $resultat['ID'] . '">';
                echo '<input type="text"  name="NomClient_modif" value="' . $resultat['NomClient'] . '">';
                echo '<input type="text"  name="Situation_modif" value="' . $resultat['Situation'] . '">';
                echo '<input type="text"  name="Telephone_modif" value="' . $resultat['Telephone'] . '">';
                echo '<input type="text"  name="Adresse_modif" value="' . $resultat['Adresse'] . '">';
                echo '<input type="text"  name="Ville_modif" value="' . $resultat['Ville'] . '">';
                echo '<input type="text"  name="Province_modif" value="' . $resultat['Province'] . '">';
                echo '<input type="text"  name="Pays_modif" value="' . $resultat['Pays'] . '">';
                echo '<input type="text"  name="CodePostal_modif" value="' . $resultat['CodePostal'] . '">';
                echo '<input type="text"  name="Adhesion_modif" value="' . $resultat['Adhesion'] . '">';
              } 
              mysqli_close($sql);


          ?>              
        </div>
        <input type="submit" name="" value="supprimer" class="envoyer">
       

    <?php }  /*fin du IF*/?>
    <?php 
      //connection
      $sql=mysqli_connect("localhost", "root", "root", "francis_vacanciers"); 
      if (!$sql) { }
      //fin de connection

      //Condition qui va regarder si les inputs sont rempli avant de faire suprimmer
        if($_REQUEST['id_bloqu'] && $_REQUEST['NomClient_modif'] && $_REQUEST['Situation_modif'] && $_REQUEST['Telephone_modif'] && $_REQUEST['Adresse_modif'] && $_REQUEST['Ville_modif'] && $_REQUEST['Province_modif'] && $_REQUEST['Pays_modif'] && $_REQUEST['CodePostal_modif'] && $_REQUEST['Adhesion_modif']) { 

          //variabiliser + nettoyer les varibles du formulaire
            $ID_net= mysqli_real_escape_string($sql, $_REQUEST['id_bloqu']);
            $NomClient_net= mysqli_real_escape_string($sql, $_REQUEST['NomClient_modif']);   
            $Situation_net= mysqli_real_escape_string($sql, $_REQUEST['Situation_modif']);
            $Telephone_net= mysqli_real_escape_string($sql, $_REQUEST['Telephone_modif']);
            $Adresse_net= mysqli_real_escape_string($sql, $_REQUEST['Adresse_modif']);
            $Ville_net= mysqli_real_escape_string($sql, $_REQUEST['Ville_modif']);
            $Province_net= mysqli_real_escape_string($sql, $_REQUEST['Province_modif']);
            $Pays_net= mysqli_real_escape_string($sql, $_REQUEST['Pays_modif']);
            $CodePostal_net= mysqli_real_escape_string($sql, $_REQUEST['CodePostal_modif']);
            $Adhesion_net= mysqli_real_escape_string($sql, $_REQUEST['Adhesion_modif']);
          //fin de variabilisation

          //création de la requpete d'insertion
            $requeteInsertion= "DELETE FROM client WHERE ID = $ID_net";  

          //effectuer la requete
            if (mysqli_query($sql, $requeteInsertion)) {  
              echo 'yes';
      }
      else{
        echo 'non';
      }
        }

      mysqli_close($sql);
    ?>      
  
    
  
    
  </form>
  <h3>Supprimer un voyage</h3>
  <form action="supprimer.php" method="POST">
     <select name="ID_select" size="1" class="info">
      <!-- Affiche les information provenant de la bd, requete SQL pour aller chercher les information et les mettre dans option.-->
        <?php 
          //  connection
          $sql=mysqli_connect("localhost", "root", "root", "francis_vacanciers");
            if (!$sql) {
            }
          //fin de connection 

          //requete
          $requete= "SELECT * FROM voyage";  
          // fin de requete
          
          //effectuer la requete
          $requeteAffiche=mysqli_query($sql, $requete);

          //Boucle pour tout afficher dans les options du formulaire
          while ($resultat=mysqli_fetch_assoc($requeteAffiche)){
            echo "<option value=\"" . $resultat['ID'] . "\">";
            echo $resultat['ID_Client'] . "-" . $resultat['Destination'] . "-" . $resultat['Depart'] . "-" . $resultat['Fin'] . "-" . $resultat['Activite'];
            echo "</option>"; 
          }
          mysqli_close($sql);

        ?>        
        </select>
    <input type="submit" name="" value="Selectionner" class="envoyer">
    <?php if($_REQUEST['ID_select']) { /*On vérifi si une valeur à été selectionner*/?> 
    <!-- 2ème action du formulaire-->

      <form action="supprimer.php" method="POST"> <!-- Si on enlève action, la page va se rafraichir d'elle même naturellement-->
        <div> 

          <?php 
            //  connection
              $sql=mysqli_connect("localhost", "root", "root", "francis_vacanciers");
                if (!$sql) {
                }
            //fin de connection 

            //nettoyage de la variable
              $selection_ID_net= mysqli_real_escape_string($sql, $_REQUEST['ID_select']);

            //requete
              $requete= "SELECT * FROM voyage WHERE ID = $selection_ID_net"; 
            // fin de requete
            
            //effectuer la requete
              $requeteAffiche=mysqli_query($sql, $requete);

            //Boucle pour tout afficher des les options du formulaire
              while ($resultat=mysqli_fetch_assoc($requeteAffiche)){
                echo '<input type="text"  name="id_bloquer" value="' . $resultat['ID'] . '">';
                echo '<input type="text"  name="ID_Client_modif" value="' . $resultat['ID_Client'] . '">';
                echo '<input type="text"  name="Destination_modif" value="' . $resultat['Destination'] . '">';
                echo '<input type="text"  name="Depart_modif" value="' . $resultat['Depart'] . '">';
                echo '<input type="text"  name="Fin_modif" value="' . $resultat['Fin'] . '">';
                echo '<input type="text"  name="Activite_modif" value="' . $resultat['Activite'] . '">';
              } 
              mysqli_close($sql);

          ?>              
        </div>
        <input type="submit" name="" value="supprimer" class="envoyer">
       

    <?php }  /*fin du IF*/?>
    <?php 
      //connection
      $sql=mysqli_connect("localhost", "root", "root", "francis_vacanciers"); 
      if (!$sql) { }
      //fin de connection

      //Condition qui va regarder si les inputs sont rempli avant de faire suprimmer
        if($_REQUEST['id_bloquer'] && $_REQUEST['ID_Client_modif'] && $_REQUEST['Destination_modif'] && $_REQUEST['Depart_modif'] && $_REQUEST['Fin_modif'] && $_REQUEST['Activite_modif']) { 

          //variabiliser + nettoyer les varibles du formulaire
            $ID_net= mysqli_real_escape_string($sql, $_REQUEST['id_bloquer']);
            $ID_Client_net= mysqli_real_escape_string($sql, $_REQUEST['ID_Client_modif']);   
            $Destination_net= mysqli_real_escape_string($sql, $_REQUEST['Destination_modif']);
            $Depart_net= mysqli_real_escape_string($sql, $_REQUEST['Depart_modif']);
            $Fin_net= mysqli_real_escape_string($sql, $_REQUEST['Fin_modif']);
            $Activite_net= mysqli_real_escape_string($sql, $_REQUEST['Activite_modif']);
          //fin de variabilisation

          //création de la requpete d'insertion
            $requeteInsertion= "DELETE FROM voyage WHERE ID = $ID_net";  

          //effectuer la requete
            if (mysqli_query($sql, $requeteInsertion)) {  
              echo 'yes';
      }
      else{
        echo 'non';
      }
        }

      mysqli_close($sql);
    ?>      
  
    
  </form>
 
  <h3>Supprimer une dépense</h3>
   <form action="supprimer.php" method="POST">
     <select name="ID_select" size="1" class="info">
      <!-- Affiche les information provenant de la bd, requete SQL pour aller chercher les information et les mettre dans option.-->
        <?php 
          //  connection
          $sql=mysqli_connect("localhost", "root", "root", "francis_vacanciers");
            if (!$sql) {
            }
          //fin de connection 

          //requete
          $requete= "SELECT * FROM finance";  
          // fin de requete
          
          //effectuer la requete
          $requeteAffiche=mysqli_query($sql, $requete);

          //Boucle pour tout afficher dans les options du formulaire
          while ($resultat=mysqli_fetch_assoc($requeteAffiche)){
            echo "<option value=\"" . $resultat['ID'] . "\">";
            echo $resultat['ID_voyage'] . "-" . $resultat['Depense'];
            echo "</option>"; 
          }
          mysqli_close($sql);

        ?>        
        </select>
    <input type="submit" name="" value="Selectionner" class="envoyer">
     </form>
  
  <?php if($_REQUEST['ID_select']) { /*On vérifi si une valeur à été selectionner*/?> 
    <!-- 2ème action du formulaire-->

      <form action="supprimer.php" method="POST"> <!-- Si on enlève action, la page va se rafraichir d'elle même naturellement-->
        <div> 

          <?php 
            //  connection
              $sql=mysqli_connect("localhost", "root", "root", "francis_vacanciers");
                if (!$sql) {
                }
            //fin de connection 

            //nettoyage de la variable
              $selection_ID_net= mysqli_real_escape_string($sql, $_REQUEST['ID_select']);

            //requete
              $requete= "SELECT * FROM finance WHERE ID = $selection_ID_net"; 
            // fin de requete
            
            //effectuer la requete
              $requeteAffiche=mysqli_query($sql, $requete);

            //Boucle pour tout afficher des les options du formulaire
              while ($resultat=mysqli_fetch_assoc($requeteAffiche)){
                echo '<input type="text"  class="id bloque" name="id_bloque" value="' . $resultat['ID'] . '">';
                echo '<input type="text" class="id" name="ID_voyage_modif" value="' . $resultat['ID_voyage'] . '">';
                echo '<input type="text" class="dep" name="depense_modif" value="' . $resultat['Depense'] . '">';
              } 
              mysqli_close($sql);

          ?>              
        </div>
        <input type="submit" name="" value="supprimer" class="envoyer">

    <?php }  /*fin du IF*/?>
    <?php 
      //connection
      $sql=mysqli_connect("localhost", "root", "root", "francis_vacanciers"); 
      if (!$sql) { }
      //fin de connection

      //Condition qui va regarder si les inputs sont rempli avant de faire l'update
        if($_REQUEST['id_bloque'] && $_REQUEST['ID_voyage_modif'] && $_REQUEST['depense_modif']) { 

          //variabiliser + nettoyer les varibles du formulaire
            $ID_net= mysqli_real_escape_string($sql, $_REQUEST['id_bloque']);
            $ID_voyage_net= mysqli_real_escape_string($sql, $_REQUEST['ID_voyage_modif']);   
            $depense_net= mysqli_real_escape_string($sql, $_REQUEST['depense_modif']);
          //fin de variabilisation

          //création de la requpete d'insertion
            $requeteInsertion= "DELETE FROM finance WHERE ID = $ID_net";  

          //effectuer la requete
            if (mysqli_query($sql, $requeteInsertion)) {  
              echo 'yes';
      }
      else{
        echo 'non';
      }
        }

      mysqli_close($sql);
    ?>      
        
      </form>
      <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
      <script src="script.js"></script>

</body>
