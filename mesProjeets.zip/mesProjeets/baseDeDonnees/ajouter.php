<html>
<head>
  <title>Ajouter des infos | Power Vacances Inc.</title>
  <link rel="stylesheet" href="style.css">
</head>
<div class="nav">
    <ul id="nav">
      <li id="email">
        <a href="ajouter.php"class="active">
          <img src="http://grantcr.com/files/iemail.png" AJOUTER/>
        </a>
      </li>
      <li id="photo">
        <a href="modifier.php">
          <img src="http://grantcr.com/files/iphoto.png"  MODIFIER/>
        </a>
      </li>
      <li id="cloud" >
        <a href="supprimer.php">
          <img src="http://grantcr.com/files/icloud.png" / SUPPRIMER>
        </a>
      </li>
     
    </ul>
  </div>
<body>
  <h1>Bienvenue sur la page d'administration de </strong>Power Vacances Inc.</strong></h1>
  <h2>Veuillez remplir les champs appropriés pour ajouter des informations.</h2>
  <h3>Ajouter un nouveau client</h3>
  <form action="action.php" method="POST">
    <input name="NomClient" placeholder="Nom du client"><br>
    <input name="Situation" placeholder="Situation Amoureuse"><br>
    <input name="Telephone" placeholder="Numéro de téléphone"><br>
    <input name="Adresse" placeholder="Adresse civique"><br>
    <input name="Ville" placeholder="Ville"><br>
    <input name="Province" placeholder="Province"><br>
    <input name="Pays" placeholder="Pays"><br>
    <input name="CodePostal" placeholder="Code Postal"><br>
    <input name="Adhesion" placeholder="Date d'adhésion"><br>
    <button><input type="submit"></button>
  </form>
  <h3>Ajouter un nouveau voyage</h3>
  <form action="action1.php" method="POST">
    <input name="ID_Client" placeholder="Identifiant du client"><br>
    <input name=" Destination" placeholder="Destination"><br>
    <input name="Depart" placeholder="Date de départ"><br>
    <input name="Fin" placeholder="Date de retour"><br>
    <input name="Activite" placeholder="Nombre d'activités"><br>
    <button><input type="submit"></button>

 
  
  
 
  </form>
  <h3>Ajouter une nouvelle dépense</h3>
  <form action="action2.php" method="POST">
    <input name="ID_voyage" placeholder="Identifiant du voyage"><br>
    <input name="Depense" placeholder="Montant de la dépense"><br>
    <button><input type="submit"></button>
  </form>
  <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script src="script.js"></script>
</body>

  
  
