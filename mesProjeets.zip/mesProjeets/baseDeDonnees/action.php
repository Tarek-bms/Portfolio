<?php  
$sql=mysqli_connect("localhost","root","root","francis_vacanciers");//connection et verifier la connection
if(!$sql){ }//etape de verification 
//fin de connexion /verification

//variabiser+nettoyer variables du formulaire
$NomClient=mysqli_real_escape_string($sql,$_REQUEST['NomClient'] );//traiter les variables+(nettoyer les info)
$Situation=mysqli_real_escape_string($sql,$_REQUEST['Situation'] );//traiter les variables+(nettoyer les info)
$Telephone=mysqli_real_escape_string($sql,$_REQUEST['Telephone'] );
$Adresse=mysqli_real_escape_string($sql,$_REQUEST['Adresse'] );
$Ville=mysqli_real_escape_string($sql,$_REQUEST['Ville'] );
$Province=mysqli_real_escape_string($sql,$_REQUEST['Province'] );
$Pays=mysqli_real_escape_string($sql,$_REQUEST['Pays'] );
$CodePostal=mysqli_real_escape_string($sql,$_REQUEST['CodePostal'] );
$Adhesion=mysqli_real_escape_string($sql,$_REQUEST['Adhesion'] );



$requete="INSERT INTO client(ID, NomClient,  Situation,  Telephone, Adresse, Ville, Province, Pays, CodePostal, Adhesion ) VALUES ('NULL', '$NomClient', '$Situation', '$Telephone', '$Adresse', '$Ville', '$Province', '$Pays', '$CodePostal', '$Adhesion')";//création de la requette d'insert
if (mysqli_query($sql, $requete)) { 
        echo 'ok';
      }
      else{
        echo 'sorry';
      }

	mysqli_close($sql);

?>                       