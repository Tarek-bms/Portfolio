<html>
<head>
  <title>Power Vacances Inc.</title>
  <link rel="stylesheet" href="style.css">
</head>
<nav>
  <div id="mainB">
  <div class="bg">
     <div class="bg1">

     </div>
  </div>
</div>
<div class="over">
  <div class="dial">
    <div class="grad">
        
    </div>
  </div>
  <div class="container">
  <div class="nav">
    <ul id="nav">
      <li id="email">
        <a href="ajouter.php">
          <img src="http://grantcr.com/files/iemail.png" AJOUTER/>
        </a>
      </li>
      <li id="photo">
        <a href="modifier.php">
          <img src="http://grantcr.com/files/iphoto.png"  MODIFIER/>
        </a>
      </li>
      <li id="cloud" class="active">
        <a href="supprimer.php">
          <img src="http://grantcr.com/files/icloud.png" / SUPPRIMER>
        </a>
      </li>
     
    </ul>
  </div>
  </div>
</div>

</nav>
<body>
<div class="contenaire">
  <h1>Bienvenue sur la page d'administration de </strong>Power Vacances Inc.</strong></h1>
  <h2>Veuillez choisir l'une des options suivantes;</h2>
  <a href="ajouter.php">Ajouter un client, voyage ou dépense</a><br>
  <a href="modifier.php">Modifier un client, voyage ou dépense</a><br>
  <a href="supprimer.php">Supprimer un client, voyage ou dépense</a><br>
  
  </div>
  <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	<script src="script.js"></script>
</body>
