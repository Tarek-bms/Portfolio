<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
	<?php
	//creer le fichier xml avec Unable to open file pour verifier qu'on peut ecrire
    $fichier2_xml = fopen("fichier2.xml", "w") or die("Unable to open file!");
 
    $sql = mysqli_connect('localhost', 'root', 'root', 'vacance');
    if(!$sql){echo "ERREUR"; //FACHÉ
    }
 
    $requete_depenses = 'SELECT * FROM client';
    $requete_boucle = mysqli_query($sql, $requete_depenses);
 
    //Initialisation de monom
    fwrite($fichier2_xml, "<?xml version=\"1.0\" encoding=\"UTF-8\"?><banque_client>");
 
    while($ligne = mysqli_fetch_assoc($requete_boucle)){
        //Remplissage de ma variable dépense avec des concaténations
 
        $client = "<client>";
        $client = $client . "<nom>" . $ligne['nom'] . "</nom>";
        $client = $client . "<situation>" . $ligne['situation'] . "</situation>";
        $client = $client . "<telephone>" . $ligne['telephone'] . "</telephone>";
        $client = $client . "<adresse>" . $ligne['adresse'] . "</adresse>";
        $client = $client . "<ville>" . $ligne['ville'] . "</ville>";
        $client = $client . "<pro>" . $ligne['pro'] . "</pro>";
        $client = $client . "<pays>" . $ligne['pays'] . "</pays>";
        $client = $client . "<cp>" . $ligne['cp'] . "</cp>";
        $client = $client . "<adhesion>" . $ligne['adhesion'] . "</adhesion>";
        $client = $client . "</client>";
 
        //Écriture dans mon fichier déclaré plus haut (fichiville
        fwrite($fichier2_xml, $client);
 
    }
    // Fermeture de mon XML dans le fichier
    fwrite($fichier2_xml, "</banque_client>");
?>
  <h1> Fichier completer, <a href="fichier2.xml" target="_blank"> TÉLÉCHARGER ICI</a></h1>            
	
</body>
</html>