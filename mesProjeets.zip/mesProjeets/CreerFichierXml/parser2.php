<!DOCTYPE html>
<html>
<head>
    <title>XML PARSENATOR V1 MWAHAHA</title>
</head>
<body>
<?php
    $xmle=simplexml_load_file("fichier1.xml") or die("Error: Cannot create object");
 
    foreach ($xmle->children() as $voyage) {
        echo "L'identifiant client est : " . $voyage->id_client;
        echo "<br>";
        echo "Et la destination est de : " . $voyage->destination;
        echo "<br>";
        echo "Et la date de depart est de : " . $voyage->depart;
        echo "<br>";
        echo "Et la date de retour est de : " . $voyage->fin;
        echo "<br>";
        echo "Et le nombre d'activité est de : " . $voyage->activite;
        echo "<br>";
    }
 
   
?>
</body>
</html>