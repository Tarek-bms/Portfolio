<!DOCTYPE html>
<html>
<head>
    <title>XML PARSENATOR V1 MWAHAHA</title>
</head>
<body>
<?php
    $xml=simplexml_load_file("fichier.xml") or die("Error: Cannot create object");
 
    foreach ($xml->children() as $depense) {
        echo "L'identifiant est : " . $depense->identifiant_voyage;
        echo "<br>";
        echo "Et le montant dépensé est de : " . $depense->montant;
        echo "<br>";
    }
 
   
?>
</body>
</html>