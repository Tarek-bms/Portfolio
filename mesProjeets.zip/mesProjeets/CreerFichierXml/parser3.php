<!DOCTYPE html>
<html>
<head>
    <title>XML PARSENATOR V1 MWAHAHA</title>
</head>
<body>
<?php
    $xmle=simplexml_load_file("fichier2.xml") or die("Error: Cannot create object");
 
    foreach ($xmle->children() as $client) {
        echo "Le nom est : " . $client->nom;
        echo "<br>";
        echo "situation est de : " . $client->situation;
        echo "<br>";
        echo "telephone est de : " . $client->telephone;
        echo "<br>";
        echo "adresse est de : " . $client->adresse;
        echo "<br>";
        echo "ville est de : " . $client->ville;
        echo "<br>";
        echo "pro est de : " . $client->pro;
        echo "<br>";
        echo "pays est de : " . $client->pays;
        echo "<br>";
        echo "cp est de : " . $client->cp;
        echo "<br>";
        echo "adhesion est de : " . $client->adhesion;
        echo "<br>";

    }
 
   
?>
</body>
</html>