<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
	 <select name="ID_select" size="1" class="info">
      <!-- Affiche les information provenant de la bd, requete SQL pour aller chercher les information et les mettre dans option.-->
        <?php 
          //  connection
          $sql=mysqli_connect("localhost", "root", "root", "vacance");
            if (!$sql) {
            }
          //fin de connection 

          //requete
          $requete= "SELECT * FROM vacance";  
          // fin de requete
          
          //effectuer la requete
          $requeteAffiche=mysqli_query($sql, $requete);

          //Boucle pour tout afficher dans les options du formulaire
          while ($resultat=mysqli_fetch_assoc($requeteAffiche)){
            echo "<option value=\"" . $resultat['ID'] . "\">";
            echo $resultat['NomClient'] . "-" . $resultat['Situation'] . "-" . $resultat['Telephone'] . "-" . $resultat['Adresse'] . "-" . $resultat['Ville'] . "-" . $resultat['Province'] . "-" . $resultat['Pays'] . "-" . $resultat['CodePostal'] . "-" . $resultat['Adhesion'];
            echo "</option>"; 
          }
          mysqli_close($sql);

        ?>        
        </select>
	
</body>
</html>