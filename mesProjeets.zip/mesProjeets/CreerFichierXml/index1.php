<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
	<?php
	//creer le fichier xml avec Unable to open file pour verifier qu'on peut ecrire
    $fichier1_xml = fopen("fichier1.xml", "w") or die("Unable to open file!");
 
    $sql = mysqli_connect('localhost', 'root', 'root', 'vacance');
    if(!$sql){echo "ERREUR"; //FACHÉ
    }
 
    $requete_depenses = 'SELECT * FROM voyage';
    $requete_boucle = mysqli_query($sql, $requete_depenses);
 
    //Initialisation de mon fichier
    fwrite($fichier1_xml, "<?xml version=\"1.0\" encoding=\"UTF-8\"?><voyage>");
 
    while($ligne = mysqli_fetch_assoc($requete_boucle)){
        //Remplissage de ma variable dépense avec des concaténations
 
        $voyage = "<voyage>";
        $voyage = $voyage . "<id_client>" . $ligne['id_client'] . "</id_client>";
        $voyage = $voyage . "<destination>" . $ligne['destination'] . "</destination>";
        $voyage = $voyage . "<depart>" . $ligne['depart'] . "</depart>";
        $voyage = $voyage . "<fin>" . $ligne['fin'] . "</fin>";
        $voyage = $voyage . "<activite>" . $ligne['activite'] . "</activite>";
        $voyage = $voyage . "</voyage>";
 
        //Écriture dans mon fichier déclaré plus haut (fichier.xml)
 
        fwrite($fichier1_xml, $voyage);
 
    }
    // Fermeture de mon XML dans le fichier
    fwrite($fichier1_xml, "</voyage>");
?>
  <h1> Fichier completer, <a href="fichier1.xml" target="_blank"> TÉLÉCHARGER ICI</a></h1>            
	
</body>
</html>