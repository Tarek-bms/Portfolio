<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
	<?php
	//creer le fichier xml avec Unable to open file pour verifier qu'on peut ecrire
    $fichier_xml = fopen("fichier.xml", "w") or die("Unable to open file!");
 
    $sql = mysqli_connect('localhost', 'root', 'root', 'vacance');
    if(!$sql){echo "ERREUR"; //FACHÉ
    }
 
    $requete_depenses = 'SELECT * FROM finance';
    $requete_boucle = mysqli_query($sql, $requete_depenses);
 
    //Initialisation de mon fichier
    fwrite($fichier_xml, "<?xml version=\"1.0\" encoding=\"UTF-8\"?><finance>");
 
    while($ligne = mysqli_fetch_assoc($requete_boucle)){
        //Remplissage de ma variable dépense avec des concaténations
 
        $depense = "<depense>";
        $depense = $depense . "<identifiant_voyage>" . $ligne['id_voyage'] . "</identifiant_voyage>";
        $depense = $depense . "<montant>" . $ligne['depense'] . "</montant>";
        $depense = $depense . "</depense>";
 
        //Écriture dans mon fichier déclaré plus haut (fichier.xml)
 
        fwrite($fichier_xml, $depense);
 
    }
    // Fermeture de mon XML dans le fichier
    fwrite($fichier_xml, "</finance>")
?>
  <h1> Fichier completer, <a href="fichier.xml" target="_blank"> TÉLÉCHARGER ICI</a></h1>            
	
</body>
</html>