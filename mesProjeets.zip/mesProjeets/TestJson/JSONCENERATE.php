<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
	<?php
	//creer le fichier xml avec Unable to open file pour verifier qu'on peut ecrire
    $fichier_json = fopen("fichier.json", "w") or die("Unable to open file!");
 
    $sql = mysqli_connect('localhost', 'root', 'root', 'vacance');
    if(!$sql){echo "ERREUR"; //FACHÉ
    }
 
    $requete_depenses = 'SELECT * FROM finance';
    $requete_boucle = mysqli_query($sql, $requete_depenses);
 
    //Initialisation de mon fichier
    
    $matrice_json= array();
    while($ligne = mysqli_fetch_assoc($requete_boucle)){
        $matrice_json[]= $ligne;
       
 
    }
    fwrite($fichier_json, json_encode($matrice_json));
   
?>
  <h1> Fichier completer, <a href="fichier.json" target="_blank"> TÉLÉCHARGER ICI</a></h1>            
	
</body>
</html>