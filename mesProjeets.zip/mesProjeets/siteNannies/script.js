$(function(){
  var accessToken = '12819982.1677ed0.7b23fcf7e5cc42b8bba701fb4cb4c06c';
  $.getJSON('https://api.instagram.com/v1/users/self/media/recent/?access_token='+accessToken+'&callback=?',function (insta) {
    $.each(insta.data,function (photos,src) {
      if ( src.caption == null){ src.caption = 'no caption'};
      if ( photos === 20 ) { return false; }
      $('<a href="'+src.link+'" target="_blank" class="post">'+
        '<div class="image" style="background-image:url('+src.images.standard_resolution.url+');"></div>'/* +
        '<div class="caption">' + src.caption.text + '</div>' */).appendTo('#content');
    });
  });
});